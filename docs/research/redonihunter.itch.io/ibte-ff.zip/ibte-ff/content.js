
const mydiv = document.createElement('div');
mydiv.setAttribute('title', `
Write a tag as seen in urls to ignore it while browsing.

tag-horror will be horror and genre-visual-novel will be visual-novel.
These rules are persisted across browser sessions and across extension updates, according to the extension api docs.
There can only be one such exclusion active.
It is an old feature of the site, that never got it's own UI Elements in the Browser pages.
So here you go.
`);
const mybutton = document.createElement('button');
mybutton.setAttribute('type', 'button');
mybutton.setAttribute('id', 'ibte_button');
mybutton.setAttribute('style', 'border: double purple');
mybutton.textContent = 'Clear';
const myinput = document.createElement('input');
myinput.setAttribute('type', 'text');
myinput.setAttribute('id', 'ibte_input');
myinput.setAttribute('placeholder', 'Exclusion');
myinput.setAttribute('style', 'border: double purple');
mydiv.appendChild(mybutton);
mydiv.appendChild(myinput);
const items = document.getElementsByClassName('browse_related_tags_widget');
const i_gave_up_figuring_out_why_it_uses_the_old_rule = 200;
mybutton.addEventListener('click', () => {
    chrome.runtime.sendMessage({ tag: false });
    setTimeout(() => (window.location.replace(window.location.origin + window.location.pathname))
        , i_gave_up_figuring_out_why_it_uses_the_old_rule);
})
myinput.addEventListener('change', () => {
    const val = myinput.value;
    chrome.runtime.sendMessage({ tag: val });
    setTimeout(() => (window.location.replace(window.location.origin + window.location.pathname + '?exclude=tg.' + val))
        , i_gave_up_figuring_out_why_it_uses_the_old_rule);
})
if (items && items.length > 0 && items[0] && items[0].children.length > 1) {
    items[0].insertBefore(mydiv, items[0].children[2]);
}







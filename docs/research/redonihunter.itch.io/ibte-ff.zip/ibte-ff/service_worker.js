if (typeof browser == "undefined") {
  globalThis.browser = chrome;
}
browser.runtime.onMessage.addListener((request, sender) => {
  if (request.tag) {
    browser.declarativeNetRequest.updateDynamicRules({
      addRules: [{
        'id': 404,
        'action': {
          'type': 'redirect',
          'redirect': {
            'transform': {
              'queryTransform': {
                'addOrReplaceParams': [{ 'key': 'exclude', 'value': 'tg.' + request.tag }]
              }
            }
          }
        },
        'condition': {
          "regexFilter": "^https://itch\\.io/(games|tools|game-assets|comics|books|physical-games|soundtracks|game-mods|misc)\.*",
          'resourceTypes': [
            'main_frame'
          ]
        }
      }],
      removeRuleIds: [404]
    })
  } else {
    browser.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [404]
    })
  }
  return true;
}); 